"""
WhatsApp Integration Tool
Allows the AI agent to communicate via WhatsApp

This provides multiple methods:
1. WhatsApp Web API (via Twilio)
2. WhatsApp Business API
3. Local WhatsApp Web automation (using Playwright)
"""

import os
import json
import time
import asyncio
from typing import Optional, Dict, List, Callable
from dataclasses import dataclass
from datetime import datetime

# Try imports
try:
    from playwright.async_api import async_playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False


@dataclass
class WhatsAppMessage:
    """Represents a WhatsApp message"""
    sender: str
    content: str
    timestamp: str
    chat_id: str
    is_from_me: bool = False


class WhatsAppTool:
    """
    WhatsApp integration for AI agent
    """

    def __init__(self, headless: bool = True):
        self.headless = headless
        self.browser = None
        self.page = None
        self.is_connected = False
        self.message_callback = None
        self.qr_code_path = "whatsapp_qr.png"

    async def connect(self) -> Dict:
        """
        Connect to WhatsApp Web
        Returns QR code for scanning or connection status
        """
        if not HAS_PLAYWRIGHT:
            return {
                "success": False,
                "error": "Playwright not installed. Run: pip install playwright && playwright install chromium"
            }

        try:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(
                headless=self.headless
            )
            context = await self.browser.new_context()
            self.page = await context.new_page()

            # Go to WhatsApp Web
            await self.page.goto('https://web.whatsapp.com')
            await asyncio.sleep(3)

            # Check if already logged in
            if await self._is_logged_in():
                self.is_connected = True
                return {
                    "success": True,
                    "status": "already_logged_in",
                    "message": "WhatsApp is connected! You can now send and receive messages."
                }

            # Wait for QR code to appear
            await asyncio.sleep(2)

            # Try to capture QR code
            qr_element = await self.page.query_selector('canvas')
            if qr_element:
                # Take screenshot of QR code
                await self.page.screenshot(path=self.qr_code_path)
                self.is_connected = False
                return {
                    "success": True,
                    "status": "qr_code_ready",
                    "message": "Scan the QR code with your WhatsApp mobile app",
                    "qr_code_path": self.qr_code_path,
                    "instructions": [
                        "1. Open WhatsApp on your phone",
                        "2. Go to Settings > Linked Devices",
                        "3. Tap 'Link a Device'",
                        "4. Scan the QR code displayed"
                    ]
                }

            return {
                "success": False,
                "error": "Could not find QR code. Please try again."
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    async def _is_logged_in(self) -> bool:
        """Check if already logged in"""
        try:
            # Look for chat elements that appear when logged in
            chat_list = await self.page.query_selector('[data-testid="chat-list"]')
            return chat_list is not None
        except:
            return False

    async def wait_for_connection(self, timeout: int = 120) -> bool:
        """Wait for user to scan QR code and connect"""
        start = time.time()
        while time.time() - start < timeout:
            if await self._is_logged_in():
                self.is_connected = True
                return True
            await asyncio.sleep(2)
        return False

    async def send_message(self, contact: str, message: str) -> Dict:
        """
        Send a message to a contact

        Args:
            contact: Phone number with country code (e.g., "+1234567890") or contact name
            message: Message to send
        """
        if not self.is_connected:
            return {
                "success": False,
                "error": "Not connected to WhatsApp. Call connect() first."
            }

        try:
            # Search for contact
            search_box = await self.page.query_selector('[data-testid="search-input"]')
            if search_box:
                await search_box.fill(contact)
                await asyncio.sleep(2)

                # Click on the contact
                contact_element = await self.page.query_selector('[data-testid="cell-frame-container"]')
                if contact_element:
                    await contact_element.click()
                    await asyncio.sleep(1)

                    # Type message
                    message_box = await self.page.query_selector('[data-testid="conversation-compose-box-input"]')
                    if message_box:
                        await message_box.fill(message)
                        await asyncio.sleep(0.5)

                        # Send
                        send_button = await self.page.query_selector('[data-testid="send-message-btn"]')
                        if send_button:
                            await send_button.click()
                            return {
                                "success": True,
                                "message": f"Message sent to {contact}",
                                "content": message
                            }

            return {
                "success": False,
                "error": f"Could not find contact: {contact}"
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    async def get_unread_messages(self) -> List[WhatsAppMessage]:
        """Get all unread messages"""
        if not self.is_connected:
            return []

        messages = []
        try:
            # Find unread chats
            unread_indicators = await self.page.query_selector_all('[data-testid="unread-count"]')

            for indicator in unread_indicators:
                # Click to open chat
                await indicator.click()
                await asyncio.sleep(1)

                # Get messages
                msg_elements = await self.page.query_selector_all('[data-testid="msg-container"]')
                for msg in msg_elements[-10:]:  # Last 10 messages
                    text = await msg.inner_text()
                    messages.append(WhatsAppMessage(
                        sender="unknown",
                        content=text,
                        timestamp=datetime.now().isoformat(),
                        chat_id="current"
                    ))

        except Exception as e:
            print(f"Error getting messages: {e}")

        return messages

    async def listen_for_messages(self, callback: Callable[[WhatsAppMessage], None],
                                   interval: int = 5):
        """
        Continuously listen for new messages

        Args:
            callback: Function to call when new message arrives
            interval: Check interval in seconds
        """
        if not self.is_connected:
            print("Not connected to WhatsApp")
            return

        print("Listening for WhatsApp messages...")
        seen_messages = set()

        while self.is_connected:
            try:
                messages = await self.get_unread_messages()
                for msg in messages:
                    msg_key = f"{msg.sender}:{msg.content}:{msg.timestamp}"
                    if msg_key not in seen_messages:
                        seen_messages.add(msg_key)
                        if callback:
                            callback(msg)
                await asyncio.sleep(interval)
            except Exception as e:
                print(f"Error in message listener: {e}")
                await asyncio.sleep(interval)

    async def disconnect(self):
        """Disconnect from WhatsApp"""
        if self.browser:
            await self.browser.close()
        self.is_connected = False


class WhatsAppBridge:
    """
    Bridge between WhatsApp and the AI Agent
    """

    def __init__(self, agent):
        self.agent = agent
        self.whatsapp = WhatsAppTool(headless=True)
        self.is_running = False

    async def setup(self) -> Dict:
        """
        Setup WhatsApp connection
        Returns instructions for user
        """
        result = await self.whatsapp.connect()

        if result.get("status") == "qr_code_ready":
            print("\n" + "="*50)
            print("📱 WHATSAPP SETUP")
            print("="*50)
            print("\nScan the QR code to connect your WhatsApp:")
            print(f"QR Code saved to: {result.get('qr_code_path')}")
            print("\nInstructions:")
            for instruction in result.get("instructions", []):
                print(f"  {instruction}")
            print("\nWaiting for connection...")

            # Wait for user to scan
            connected = await self.whatsapp.wait_for_connection(timeout=120)

            if connected:
                print("\n✅ WhatsApp connected!")
                return {"success": True, "status": "connected"}
            else:
                print("\n❌ Connection timeout")
                return {"success": False, "error": "Connection timeout"}

        return result

    async def start_listening(self):
        """Start listening for messages and responding"""
        if not self.whatsapp.is_connected:
            print("Not connected. Call setup() first.")
            return

        self.is_running = True
        print("\n🤖 WhatsApp Bot is now running!")
        print("Send a message to your WhatsApp to interact with the AI.")
        print("Type 'stop' in terminal to stop.\n")

        last_messages = set()

        while self.is_running:
            try:
                messages = await self.whatsapp.get_unread_messages()

                for msg in messages:
                    msg_id = f"{msg.sender}:{msg.content[:50]}"

                    if msg_id not in last_messages and not msg.is_from_me:
                        last_messages.add(msg_id)

                        print(f"\n📩 From {msg.sender}: {msg.content[:100]}...")

                        # Get AI response
                        response = self.agent.run(msg.content)

                        # Send response
                        await self.whatsapp.send_message(msg.sender, response)
                        print(f"📤 Sent response to {msg.sender}")

                await asyncio.sleep(3)

            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(5)

    def stop(self):
        """Stop listening"""
        self.is_running = False


def setup_whatsapp_bot(agent) -> Dict:
    """
    Setup function to be called from main agent
    """
    async def _setup():
        bridge = WhatsAppBridge(agent)
        result = await bridge.setup()

        if result.get("success"):
            await bridge.start_listening()

        return result

    # Run async setup
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    return loop.run_until_complete(_setup())


# Tool definition for tool manager
TOOLS = [
    {
        "name": "whatsapp_send",
        "description": "Send a message via WhatsApp",
        "function": "send_whatsapp_message",
        "parameters": {
            "contact": {"type": "string", "description": "Phone number or contact name"},
            "message": {"type": "string", "description": "Message to send"}
        },
        "category": "communication"
    },
    {
        "name": "whatsapp_setup",
        "description": "Setup WhatsApp connection for the AI bot",
        "function": "setup_whatsapp_bot_tool",
        "parameters": {},
        "category": "communication"
    }
]


def send_whatsapp_message(contact: str, message: str) -> str:
    """Send WhatsApp message (synchronous wrapper)"""
    async def _send():
        tool = WhatsAppTool()
        await tool.connect()
        result = await tool.send_message(contact, message)
        await tool.disconnect()
        return result

    loop = asyncio.new_event_loop()
    result = loop.run_until_complete(_send())
    return json.dumps(result)


def setup_whatsapp_bot_tool() -> str:
    """Setup WhatsApp bot for AI agent"""
    return "WhatsApp bot setup initiated. Check the terminal for QR code."


if __name__ == "__main__":
    print("WhatsApp Tool Test")
    print("="*50)
    print("\nTo use WhatsApp integration:")
    print("1. Install playwright: pip install playwright && playwright install chromium")
    print("2. Run this script")
    print("3. Scan the QR code with your phone")
    print("\nStarting connection...")

    async def test():
        tool = WhatsAppTool(headless=False)
        result = await tool.connect()
        print(json.dumps(result, indent=2))

        if result.get("status") == "qr_code_ready":
            print("\nWaiting for you to scan the QR code...")
            connected = await tool.wait_for_connection()
            if connected:
                print("Connected! You can now send messages.")

    asyncio.run(test())
